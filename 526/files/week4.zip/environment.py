import utils
from typing import Any


class Environment:

    def __init__(self, map_path: str):
        self.file_path: str = map_path
        self.world: list = self.load_assets(self.load_map())

    def load_map(self) -> list:
        try:
            with open(self.file_path) as f:
                world_map = [[col.lower() for col in line.strip()] for line in f]

                # quick error check
                first_row = len(world_map[0])
                for row in world_map:
                    if len(row) != first_row:
                        raise Exception("Map rows are not even")
                return world_map
        except FileNotFoundError:
            print(f"File not found")
        except PermissionError:
            print(f"File read permissions were denied")
        except IOError as e:
            print(f"IO error: {e}")

        return []

    def load_assets(self, world_map:list) -> list:
        for i in range(len(world_map)):
            for j in range(len(world_map[i])):
                if world_map[i][j] == 's':
                    world_map[i][j] = utils.WaterStation((j, i))
                elif world_map[i][j] == 'r':
                    world_map[i][j] = utils.Robot((j, i))
                elif world_map[i][j] == '*':
                    world_map[i][j] = utils.Flame()
        return world_map

    def get_cells(self, positions:list) -> dict[tuple[int,int], Any]:
        cells = {}
        for pos in positions:
            cells[pos] = self.world[pos[1]][pos[0]]
        return cells

    def __str__(self):
        out = ""
        for row in self.world:
            for col in row:
                out += f"{col}\t"
            out += "\n"
        return out


if __name__ == "__main__":
    e = Environment("map.txt")

    water = e.world[1][5]
    robot1 = e.world[5][5]

    for i in range(1):  # Change 1 simulate more moves. I.e. 100 would simulate 100 moves
        # Call the act method for each agent operating in the environment
        print(e)


