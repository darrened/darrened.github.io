from fact import Fact
from rule import Rule
from result import Result


class ExpertSystem:

    def __init__(self, rules: list[Rule]):
        self.rules = rules

    def run(self, initial_facts: set[Fact]) -> Result:
        facts = set(initial_facts)
        fired_rules = {}

        changed = True

        while changed:
            changed = False

            for rule in self.rules:
                if rule.is_satisfied_by(facts):
                    conclusion = rule.conclusion

                    if conclusion not in facts:
                        facts.add(conclusion)
                        fired_rules[conclusion] = rule
                        changed = True

        return Result(
            initial_facts=initial_facts,
            facts=facts,
            fired_rules=fired_rules
        )

    def explain(self, conclusion: Fact, result: Result) -> str:

        if conclusion in result.initial_facts:
            return f"✓ {conclusion} (given)"

        rule = result.fired_rules.get(conclusion)

        if rule is None:
            return f"No explanation available for: {conclusion}"

        lines = []

        self._build_explanation(rule, result, lines, indent=0)

        return "\n".join(lines)

    def _build_explanation(self, rule: Rule, result: Result, lines: list[str], indent: int):
        prefix = " " * indent

        lines.append(f"{prefix}✓ {rule.conclusion}")
        lines.append(f"{prefix}  because: {rule.name}")

        for condition in rule.conditions:
            if condition in result.initial_facts:
                lines.append(f"{prefix}    ✓ {condition} (given)")
            else:
                supporting_rule = result.fired_rules.get(condition)

                if supporting_rule is not None:
                    self._build_explanation(
                        supporting_rule,
                        result,
                        lines,
                        indent + 4
                    )
