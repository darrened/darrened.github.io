from dataclasses import dataclass


@dataclass(frozen=True)
class Fact:
    name: str

    def __str__(self):
        return self.name
