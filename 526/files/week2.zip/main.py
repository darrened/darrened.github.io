from expert_system import Fact, Rule, ExpertSystem


initial_facts = {
    Fact("sunny"),
    Fact("weekend")
}

# ---------------------------------------------------------
# Rules
# ---------------------------------------------------------

rules = [

    Rule(
        name="Eye protection required",
        conditions=[
            Fact("sunny")
        ],
        conclusion=Fact("Wear Sunglasses")
    ),

    Rule(
        name="Need to keep dry",
        conditions=[
            Fact("rainy")
        ],
        conclusion=Fact("Take Umbrella")
    ),

    Rule(
        name="Activity recommended for nice days",
        conditions=[
            Fact("sunny"),
            Fact("weekend")
        ],
        conclusion=Fact("Go to Beach")
    ),

    Rule(
            name="Food recommended at beach",
            conditions=[
                Fact("Go to Beach"),
            ],
            conclusion=Fact("Buy Ice Cream")
        )
]


# ---------------------------------------------------------
# Create the expert system
# ---------------------------------------------------------

system = ExpertSystem(rules)

result = system.run(initial_facts)

print("Initial Facts:")
for fact in result.initial_facts:
    print(f"\t- {fact}")

print("Rules fired:")

for rule in result.fired_rules:
    print(f"\t- {rule}")

print("\nFacts derived:")

for fact in result.facts - result.initial_facts:
    print(f" - {fact}")

print("\nExplanation")
explanation = system.explain(Fact("Buy Ice Cream"), result)
print(explanation)