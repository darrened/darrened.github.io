from dataclasses import dataclass
from fact import Fact


@dataclass(frozen=True)
class Rule():
    name: str
    conditions: list[Fact]
    conclusion: Fact

    def is_satisfied_by(self, facts: set[Fact]) -> bool:
        return all(
            condition in facts
            for condition in self.conditions
        )
