from dataclasses import dataclass
from fact import Fact
from rule import Rule


@dataclass
class Result:
    initial_facts: set[Fact]
    facts: set[Fact]
    fired_rules: dict[Fact, Rule]
